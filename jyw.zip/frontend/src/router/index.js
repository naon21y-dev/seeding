import { createRouter, createWebHistory } from 'vue-router'

import DashboardView from '@/views/dashboard/DashboardView.vue'

import CampaignListView from '@/views/campaigns/CampaignListView.vue'
import CampaignCreateView from '@/views/campaigns/CampaignCreateView.vue'
import CampaignDetailView from '@/views/campaigns/CampaignDetailView.vue'

import InfluencerListView from '@/views/influencers/InfluencerListView.vue'
import InfluencerCreateView from '@/views/influencers/InfluencerCreateView.vue'

import ShipmentListView from '@/views/shipments/ShipmentListView.vue'
import ContentListView from '@/views/contents/ContentListView.vue'
import AnalyticsView from '@/views/analytics/AnalyticsView.vue'

const router = createRouter({
  history: createWebHistory(),

  routes: [
    {
      path: '/',
      name: 'dashboard',
      component: DashboardView,
    },

    {
      path: '/campaigns',
      name: 'campaigns',
      component: CampaignListView,
    },

    {
      path: '/campaigns/new',
      name: 'campaign-create',
      component: CampaignCreateView,
    },

    {
      path: '/campaigns/:id',
      name: 'campaign-detail',
      component: CampaignDetailView,
    },

    {
      path: '/influencers',
      name: 'influencers',
      component: InfluencerListView,
    },

    {
      path: '/influencers/new',
      name: 'influencer-create',
      component: InfluencerCreateView,
    },

    {
      path: '/shipments',
      component: ShipmentListView,
    },

    {
      path: '/contents',
      component: ContentListView,
    },

    {
      path: '/analytics',
      component: AnalyticsView,
    },
  ],
})

export default router