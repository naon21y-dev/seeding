<script setup>
import { RouterLink } from 'vue-router'
</script>

<template>

  <aside class="sidebar">

    <div class="sidebar-logo">

      <div class="logo-mark">
        S
      </div>

      <div>
        <strong>
          SEEDLY
        </strong>

        <span>
          BEAUTY SEEDING
        </span>
      </div>

    </div>

    <nav class="sidebar-menu">

      <span class="menu-title">
        OVERVIEW
      </span>

      <RouterLink to="/">
        Dashboard
      </RouterLink>


      <span class="menu-title">
        SEEDING
      </span>

      <RouterLink to="/campaigns">
        Campaigns
      </RouterLink>

      <RouterLink to="/influencers">
        Influencers
      </RouterLink>

      <RouterLink to="/shipments">
        Shipments
      </RouterLink>


      <span class="menu-title">
        CONTENT
      </span>

      <RouterLink to="/contents">
        Contents
      </RouterLink>

      <RouterLink to="/analytics">
        Analytics
      </RouterLink>

    </nav>

    <div class="sidebar-footer">

      <div class="sidebar-user">

        <div class="avatar">
          M
        </div>

        <div>
          <strong>
            Beauty Team
          </strong>

          <span>
            Marketing
          </span>
        </div>

      </div>

    </div>

  </aside>

</template>