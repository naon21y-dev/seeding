<script setup>
const shipments = [
  {
    influencer: '김민아',
    account: '@beauty_mina',
    product: 'Glow Tint',
    option: '03 Berry',
    courier: 'CJ대한통운',
    tracking: '589321044321',
    status: '배송완료',
  },

  {
    influencer: '박수진',
    account: '@suu_makeup',
    product: 'Glow Tint',
    option: '01 Peach',
    courier: '한진택배',
    tracking: '443821930012',
    status: '배송중',
  },

  {
    influencer: '이지윤',
    account: '@ji_yoon',
    product: 'Glow Cushion',
    option: '21 Ivory',
    courier: '-',
    tracking: '-',
    status: '발송준비',
  },
]
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          LOGISTICS
        </span>

        <h1>
          Shipments
        </h1>

        <p>
          시딩 제품 발송과 배송 현황을 관리합니다.
        </p>

      </div>

    </div>


    <div class="table-card">

      <table>

        <thead>
          <tr>
            <th>INFLUENCER</th>
            <th>PRODUCT</th>
            <th>OPTION</th>
            <th>COURIER</th>
            <th>TRACKING</th>
            <th>STATUS</th>
          </tr>
        </thead>


        <tbody>

          <tr
            v-for="item in shipments"
            :key="item.tracking"
          >

            <td>

              <div class="table-profile">

                <strong>
                  {{ item.influencer }}
                </strong>

                <span>
                  {{ item.account }}
                </span>

              </div>

            </td>

            <td>
              {{ item.product }}
            </td>

            <td>
              {{ item.option }}
            </td>

            <td>
              {{ item.courier }}
            </td>

            <td>
              {{ item.tracking }}
            </td>

            <td>

              <span
                class="status-badge"
                :class="{
                  'status-active':
                    item.status === '배송완료',

                  'status-warning':
                    item.status === '배송중',
                }"
              >
                {{ item.status }}
              </span>

            </td>

          </tr>

        </tbody>

      </table>

    </div>

  </section>

</template>