<script setup>
const contents = [
  {
    influencer: '@beauty_mina',
    platform: 'Instagram',
    campaign: 'FW Glow Tint',
    views: 82400,
    likes: 4320,
    comments: 182,
    saves: 1020,
  },

  {
    influencer: '@suu_makeup',
    platform: 'TikTok',
    campaign: 'FW Glow Tint',
    views: 151200,
    likes: 9830,
    comments: 430,
    saves: 2880,
  },
]
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          SOCIAL CONTENT
        </span>

        <h1>
          Contents
        </h1>

        <p>
          시딩 후 업로드된 콘텐츠와 성과를 확인합니다.
        </p>

      </div>

    </div>


    <div class="content-grid">

      <article
        v-for="item in contents"
        :key="item.influencer"
        class="content-card"
      >

        <div class="content-image">
          SOCIAL CONTENT
        </div>

        <div class="content-info">

          <span>
            {{ item.platform }}
          </span>

          <strong>
            {{ item.influencer }}
          </strong>

          <small>
            {{ item.campaign }}
          </small>

        </div>


        <div class="metrics">

          <div>
            <span>VIEWS</span>

            <strong>
              {{
                item.views
                  .toLocaleString()
              }}
            </strong>
          </div>

          <div>
            <span>LIKES</span>

            <strong>
              {{
                item.likes
                  .toLocaleString()
              }}
            </strong>
          </div>

          <div>
            <span>SAVES</span>

            <strong>
              {{
                item.saves
                  .toLocaleString()
              }}
            </strong>
          </div>

        </div>

      </article>

    </div>

  </section>

</template>

<style scoped>
.content-grid {
  display: grid;

  grid-template-columns:
    repeat(3, 1fr);

  gap: 16px;
}

.content-card {
  overflow: hidden;

  background: white;

  border: 1px solid #ececef;

  border-radius: 16px;
}

.content-image {
  height: 230px;

  display: flex;
  align-items: center;
  justify-content: center;

  background:
    linear-gradient(
      135deg,
      #eee4e7,
      #eaeaea
    );

  color: #9a848c;

  font-size: 10px;
  font-weight: 800;
}

.content-info {
  display: flex;
  flex-direction: column;

  gap: 5px;

  padding: 18px;
}

.content-info span {
  color: #999;

  font-size: 9px;
}

.content-info strong {
  font-size: 14px;
}

.content-info small {
  color: #999;
}

.metrics {
  display: grid;

  grid-template-columns:
    repeat(3, 1fr);

  padding:
    15px 18px;

  border-top:
    1px solid #eee;
}

.metrics div {
  display: flex;
  flex-direction: column;

  gap: 4px;
}

.metrics span {
  color: #aaa;

  font-size: 8px;
}

.metrics strong {
  font-size: 11px;
}
</style>