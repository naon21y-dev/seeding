<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router =
  useRouter()

const search =
  ref('')

const influencers =
  ref([
    {
      id: 1,
      name: '김민아',
      account: '@beauty_mina',
      platform: 'Instagram',
      followers: 82400,
      views: 45100,
      category: 'Makeup',
      skin: '복합성',
      color: '여름쿨',
    },

    {
      id: 2,
      name: '박수진',
      account: '@suu_makeup',
      platform: 'TikTok',
      followers: 124000,
      views: 97300,
      category: 'Beauty',
      skin: '지성',
      color: '겨울쿨',
    },

    {
      id: 3,
      name: '이지윤',
      account: '@ji_yoon',
      platform: 'Instagram',
      followers: 53600,
      views: 32200,
      category: 'Skincare',
      skin: '건성',
      color: '봄웜',
    },

    {
      id: 4,
      name: '최하늘',
      account: '@haneul_beauty',
      platform: 'YouTube',
      followers: 213000,
      views: 118000,
      category: 'Beauty',
      skin: '민감성',
      color: '가을웜',
    },
  ])

const filtered =
  computed(() => {

    const keyword =
      search.value
        .toLowerCase()

    return influencers.value.filter(
      item =>
        item.name
          .toLowerCase()
          .includes(keyword)
        ||
        item.account
          .toLowerCase()
          .includes(keyword)
    )
  })
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          CREATOR DATABASE
        </span>

        <h1>
          Influencers
        </h1>

        <p>
          시딩 인플루언서 정보를 관리합니다.
        </p>

      </div>

      <button
        class="primary-button"

        @click="
          router.push(
            '/influencers/new'
          )
        "
      >
        + 인플루언서 등록
      </button>

    </div>


    <div class="toolbar">

      <input
        v-model="search"
        placeholder="이름 또는 계정 검색"
      />

      <select>
        <option>
          전체 플랫폼
        </option>

        <option>
          Instagram
        </option>

        <option>
          TikTok
        </option>

        <option>
          YouTube
        </option>
      </select>

    </div>


    <div class="table-card">

      <table>

        <thead>

          <tr>
            <th>
              INFLUENCER
            </th>

            <th>
              PLATFORM
            </th>

            <th>
              FOLLOWERS
            </th>

            <th>
              AVG VIEWS
            </th>

            <th>
              CATEGORY
            </th>

            <th>
              SKIN TYPE
            </th>

            <th>
              PERSONAL COLOR
            </th>
          </tr>

        </thead>


        <tbody>

          <tr
            v-for="item in filtered"
            :key="item.id"
          >

            <td>

              <div class="table-profile">

                <strong>
                  {{ item.name }}
                </strong>

                <span>
                  {{ item.account }}
                </span>

              </div>

            </td>

            <td>
              {{ item.platform }}
            </td>

            <td>
              {{
                item.followers
                  .toLocaleString()
              }}
            </td>

            <td>
              {{
                item.views
                  .toLocaleString()
              }}
            </td>

            <td>
              {{ item.category }}
            </td>

            <td>
              {{ item.skin }}
            </td>

            <td>
              {{ item.color }}
            </td>

          </tr>

        </tbody>

      </table>

    </div>

  </section>

</template>

<style scoped>
.toolbar {
  display: flex;

  gap: 10px;

  margin-bottom: 18px;
}

.toolbar input {
  width: 330px;
}

.toolbar input,
.toolbar select {
  padding: 11px 13px;

  border: 1px solid #dedee3;

  border-radius: 9px;

  background: white;
}
</style>