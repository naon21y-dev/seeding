<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'

const router =
  useRouter()

const form =
  reactive({
    name: '',
    account: '',
    platform: 'Instagram',
    followers: 0,
    views: 0,
    email: '',
    phone: '',
    address: '',
    category: 'Beauty',
    skin: '',
    personalColor: '',
    memo: '',
  })

const submit =
  () => {

    console.log(form)

    alert(
      '인플루언서가 등록되었습니다.'
    )

    router.push(
      '/influencers'
    )
  }
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          NEW CREATOR
        </span>

        <h1>
          Add Influencer
        </h1>

        <p>
          새로운 시딩 인플루언서를 등록합니다.
        </p>

      </div>

    </div>


    <form
      class="form-card"
      @submit.prevent="submit"
    >

      <div class="form-grid">

        <div class="form-group">

          <label>
            이름
          </label>

          <input
            v-model="form.name"
            required
          />

        </div>


        <div class="form-group">

          <label>
            SNS 계정
          </label>

          <input
            v-model="form.account"
            placeholder="@account"
          />

        </div>


        <div class="form-group">

          <label>
            플랫폼
          </label>

          <select
            v-model="form.platform"
          >
            <option>
              Instagram
            </option>

            <option>
              TikTok
            </option>

            <option>
              YouTube
            </option>

            <option>
              Blog
            </option>
          </select>

        </div>


        <div class="form-group">

          <label>
            카테고리
          </label>

          <input
            v-model="form.category"
          />

        </div>


        <div class="form-group">

          <label>
            팔로워
          </label>

          <input
            v-model.number="form.followers"
            type="number"
          />

        </div>


        <div class="form-group">

          <label>
            평균 조회수
          </label>

          <input
            v-model.number="form.views"
            type="number"
          />

        </div>


        <div class="form-group">

          <label>
            피부 타입
          </label>

          <select
            v-model="form.skin"
          >
            <option value="">
              선택
            </option>

            <option>
              건성
            </option>

            <option>
              지성
            </option>

            <option>
              복합성
            </option>

            <option>
              민감성
            </option>
          </select>

        </div>


        <div class="form-group">

          <label>
            퍼스널 컬러
          </label>

          <select
            v-model="form.personalColor"
          >
            <option value="">
              선택
            </option>

            <option>
              봄웜
            </option>

            <option>
              여름쿨
            </option>

            <option>
              가을웜
            </option>

            <option>
              겨울쿨
            </option>
          </select>

        </div>


        <div class="form-group">

          <label>
            이메일
          </label>

          <input
            v-model="form.email"
            type="email"
          />

        </div>


        <div class="form-group">

          <label>
            연락처
          </label>

          <input
            v-model="form.phone"
          />

        </div>


        <div class="form-group full">

          <label>
            배송지
          </label>

          <input
            v-model="form.address"
          />

        </div>


        <div class="form-group full">

          <label>
            메모
          </label>

          <textarea
            v-model="form.memo"
          />

        </div>

      </div>


      <div class="form-actions">

        <button
          type="button"
          class="secondary-button"

          @click="router.back()"
        >
          취소
        </button>

        <button
          class="primary-button"
        >
          등록
        </button>

      </div>

    </form>

  </section>

</template>