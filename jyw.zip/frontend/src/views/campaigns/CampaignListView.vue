<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const search = ref('')

const campaigns = ref([
  {
    id: 1,
    name: 'FW Glow Tint Seeding',
    product: 'Glow Tint',
    status: '진행중',
    target: 100,
    current: 82,
    uploads: 61,
    deadline: '2026-10-15',
  },

  {
    id: 2,
    name: 'Glass Skin Cushion',
    product: 'Glow Cushion',
    status: '진행중',
    target: 70,
    current: 54,
    uploads: 29,
    deadline: '2026-10-20',
  },

  {
    id: 3,
    name: 'Autumn MLBB Collection',
    product: 'Velvet Lip',
    status: '진행중',
    target: 80,
    current: 61,
    uploads: 42,
    deadline: '2026-10-12',
  },

  {
    id: 4,
    name: 'Summer Fixing Mist',
    product: 'Fixing Mist',
    status: '완료',
    target: 50,
    current: 50,
    uploads: 48,
    deadline: '2026-08-30',
  },
])

const filtered = computed(() => {
  return campaigns.value.filter(item =>
    item.name
      .toLowerCase()
      .includes(
        search.value.toLowerCase()
      )
  )
})
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          CAMPAIGN
        </span>

        <h1>
          Campaigns
        </h1>

        <p>
          시딩 캠페인을 생성하고 진행 상황을 관리합니다.
        </p>

      </div>

      <button
        class="primary-button"
        @click="
          router.push('/campaigns/new')
        "
      >
        + 캠페인 생성
      </button>

    </div>


    <div class="toolbar">

      <input
        v-model="search"
        placeholder="캠페인 검색"
      />

      <select>
        <option>
          전체 상태
        </option>

        <option>
          진행중
        </option>

        <option>
          완료
        </option>
      </select>

    </div>


    <div class="campaign-grid">

      <article
        v-for="campaign in filtered"

        :key="campaign.id"

        class="campaign-card"

        @click="
          router.push(
            `/campaigns/${campaign.id}`
          )
        "
      >

        <div class="card-top">

          <span
            class="status-badge"
            :class="
              campaign.status === '진행중'
                ? 'status-active'
                : ''
            "
          >
            {{ campaign.status }}
          </span>

          <span class="menu-dots">
            ···
          </span>

        </div>


        <div class="campaign-product">
          BEAUTY PRODUCT
        </div>


        <h3>
          {{ campaign.name }}
        </h3>

        <p>
          {{ campaign.product }}
        </p>


        <div class="progress">

          <div class="progress-info">
            <span>시딩 진행률</span>

            <strong>
              {{ campaign.current }}
              /
              {{ campaign.target }}
            </strong>
          </div>

          <div class="progress-bar">

            <div
              :style="{
                width:
                  campaign.current /
                  campaign.target *
                  100 + '%'
              }"
            />

          </div>

        </div>


        <div class="card-footer">

          <div>
            <span>UPLOAD</span>

            <strong>
              {{ campaign.uploads }}
            </strong>
          </div>

          <div>
            <span>DEADLINE</span>

            <strong>
              {{ campaign.deadline }}
            </strong>
          </div>

        </div>

      </article>

    </div>

  </section>

</template>

<style scoped>
.toolbar {
  display: flex;

  gap: 10px;

  margin-bottom: 20px;
}

.toolbar input {
  width: 300px;
}

.toolbar input,
.toolbar select {
  padding: 11px 13px;

  border: 1px solid #dedee3;
  border-radius: 9px;

  background: white;
}

.campaign-grid {
  display: grid;

  grid-template-columns:
    repeat(3, 1fr);

  gap: 16px;
}

.campaign-card {
  padding: 20px;

  background: white;

  border:
    1px solid #ececef;

  border-radius: 17px;

  cursor: pointer;

  transition: 0.2s;
}

.campaign-card:hover {
  transform:
    translateY(-3px);

  box-shadow:
    0 15px 35px
    rgba(0, 0, 0, 0.05);
}

.card-top {
  display: flex;
  justify-content:
    space-between;
}

.menu-dots {
  color: #999;
}

.campaign-product {
  height: 130px;

  display: flex;
  align-items: center;
  justify-content: center;

  margin:
    17px 0;

  border-radius: 14px;

  background:
    linear-gradient(
      135deg,
      #f5eff1,
      #efefef
    );

  color: #9b8c92;

  font-size: 10px;
  font-weight: 800;

  letter-spacing: 1px;
}

.campaign-card h3 {
  margin:
    0 0 7px;

  font-size: 15px;
}

.campaign-card p {
  margin: 0;

  color: #999;

  font-size: 11px;
}

.progress {
  margin-top: 22px;
}

.progress-info {
  display: flex;
  justify-content:
    space-between;

  margin-bottom: 7px;

  font-size: 10px;
}

.progress-info span {
  color: #999;
}

.progress-bar {
  height: 5px;

  overflow: hidden;

  background: #ededf0;

  border-radius: 20px;
}

.progress-bar div {
  height: 100%;

  background: #252528;

  border-radius: 20px;
}

.card-footer {
  display: flex;

  justify-content:
    space-between;

  margin-top: 22px;

  padding-top: 15px;

  border-top:
    1px solid #eee;
}

.card-footer div {
  display: flex;
  flex-direction: column;

  gap: 5px;
}

.card-footer span {
  color: #aaa;

  font-size: 8px;
}

.card-footer strong {
  font-size: 10px;
}
</style>