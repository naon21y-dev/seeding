<script setup>
import { ref } from 'vue'

const statusOptions = [
  '후보',
  '컨택 완료',
  '수락',
  '주소 수집',
  '발송 준비',
  '발송 완료',
  '배송 완료',
  '업로드 대기',
  '업로드 완료',
]

const influencers =
  ref([
    {
      id: 1,
      name: '김민아',
      account: '@beauty_mina',
      platform: 'Instagram',
      follower: 82400,
      deadline: 'D-2',
      status: '업로드 대기',
    },

    {
      id: 2,
      name: '박수진',
      account: '@suu_makeup',
      platform: 'TikTok',
      follower: 124000,
      deadline: 'D-5',
      status: '배송 완료',
    },

    {
      id: 3,
      name: '이지윤',
      account: '@ji_yoon',
      platform: 'Instagram',
      follower: 53600,
      deadline: '2일 초과',
      status: '업로드 대기',
    },

    {
      id: 4,
      name: '최하늘',
      account: '@haneul_beauty',
      platform: 'YouTube',
      follower: 213000,
      deadline: '완료',
      status: '업로드 완료',
    },
  ])
</script>

<template>

  <section>

    <div class="detail-header">

      <div>

        <span class="status-badge status-active">
          진행중
        </span>

        <h1>
          FW Glow Tint Seeding
        </h1>

        <p>
          Beauty Brand · Glow Tint
        </p>

      </div>

      <button class="primary-button">
        + 인플루언서 추가
      </button>

    </div>


    <div class="detail-summary">

      <div>
        <span>
          전체 시딩
        </span>

        <strong>
          82
        </strong>
      </div>

      <div>
        <span>
          배송 완료
        </span>

        <strong>
          74
        </strong>
      </div>

      <div>
        <span>
          콘텐츠 업로드
        </span>

        <strong>
          61
        </strong>
      </div>

      <div>
        <span>
          기한 초과
        </span>

        <strong class="danger">
          7
        </strong>
      </div>

    </div>


    <div class="campaign-info-bar">

      <div>

        <span>
          CAMPAIGN PERIOD
        </span>

        <strong>
          2026.09.20 -
          2026.10.20
        </strong>

      </div>

      <div>

        <span>
          CONTENT DEADLINE
        </span>

        <strong>
          2026.10.15
        </strong>

      </div>

      <div>

        <span>
          TARGET
        </span>

        <strong>
          100 Influencers
        </strong>

      </div>

    </div>


    <div class="table-card">

      <table>

        <thead>

          <tr>
            <th>
              INFLUENCER
            </th>

            <th>
              PLATFORM
            </th>

            <th>
              FOLLOWERS
            </th>

            <th>
              DEADLINE
            </th>

            <th>
              STATUS
            </th>

            <th>
              SHIPMENT
            </th>

            <th>
              CONTENT
            </th>
          </tr>

        </thead>


        <tbody>

          <tr
            v-for="item in influencers"

            :key="item.id"
          >

            <td>

              <div class="table-profile">

                <strong>
                  {{ item.name }}
                </strong>

                <span>
                  {{ item.account }}
                </span>

              </div>

            </td>

            <td>
              {{ item.platform }}
            </td>

            <td>
              {{
                item.follower
                  .toLocaleString()
              }}
            </td>

            <td>

              <span
                :class="{
                  overdue:
                    item.deadline
                      .includes(
                        '초과'
                      )
                }"
              >
                {{ item.deadline }}
              </span>

            </td>

            <td>

              <select
                v-model="item.status"
                class="status-select"
              >

                <option
                  v-for="status in statusOptions"

                  :key="status"
                >
                  {{ status }}
                </option>

              </select>

            </td>

            <td>

              <button class="table-action">
                배송 관리
              </button>

            </td>

            <td>

              <button class="table-action">
                콘텐츠 등록
              </button>

            </td>

          </tr>

        </tbody>

      </table>

    </div>

  </section>

</template>

<style scoped>
.detail-header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;

  margin-bottom: 25px;
}

.detail-header h1 {
  margin:
    12px 0 5px;

  font-size: 30px;
}

.detail-header p {
  margin: 0;

  color: #999;

  font-size: 12px;
}

.detail-summary {
  display: grid;

  grid-template-columns:
    repeat(4, 1fr);

  gap: 15px;

  margin-bottom: 15px;
}

.detail-summary > div {
  display: flex;

  flex-direction: column;

  padding: 20px;

  border:
    1px solid #ececef;

  border-radius: 15px;

  background: white;
}

.detail-summary span {
  color: #999;

  font-size: 10px;
}

.detail-summary strong {
  margin-top: 9px;

  font-size: 26px;
}

.danger {
  color: #d84343;
}

.campaign-info-bar {
  display: flex;

  gap: 70px;

  padding: 18px 22px;

  margin-bottom: 15px;

  background: white;

  border:
    1px solid #ececef;

  border-radius: 14px;
}

.campaign-info-bar div {
  display: flex;

  flex-direction: column;

  gap: 5px;
}

.campaign-info-bar span {
  color: #aaa;

  font-size: 8px;

  letter-spacing: 1px;
}

.campaign-info-bar strong {
  font-size: 11px;
}

.status-select {
  padding: 8px 10px;

  border:
    1px solid #ddd;

  border-radius: 8px;

  background: white;

  font-size: 11px;
}

.table-action {
  padding: 8px 10px;

  border:
    1px solid #ddd;

  border-radius: 7px;

  background: white;

  font-size: 10px;
}

.overdue {
  color: #d84343;

  font-weight: 700;
}
</style>