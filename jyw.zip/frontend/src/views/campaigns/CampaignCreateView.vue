<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'

const router =
  useRouter()

const form =
  reactive({
    name: '',
    brand: '',
    product: '',
    target: 50,
    startDate: '',
    endDate: '',
    deadline: '',
    platform: 'Instagram',
    description: '',
  })

const submit =
  () => {

    console.log(
      'campaign:',
      form
    )

    alert(
      '캠페인이 생성되었습니다.'
    )

    router.push(
      '/campaigns'
    )
  }
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          NEW CAMPAIGN
        </span>

        <h1>
          Create Campaign
        </h1>

        <p>
          새로운 인플루언서 시딩 캠페인을 등록합니다.
        </p>

      </div>

    </div>


    <form
      class="form-card"
      @submit.prevent="submit"
    >

      <div class="form-grid">

        <div class="form-group full">

          <label>
            캠페인명
          </label>

          <input
            v-model="form.name"
            required
            placeholder="예: FW Glow Tint Seeding"
          />

        </div>


        <div class="form-group">

          <label>
            브랜드명
          </label>

          <input
            v-model="form.brand"
            placeholder="브랜드"
          />

        </div>


        <div class="form-group">

          <label>
            제품명
          </label>

          <input
            v-model="form.product"
            placeholder="제품명"
          />

        </div>


        <div class="form-group">

          <label>
            목표 시딩 인원
          </label>

          <input
            v-model.number="form.target"
            type="number"
          />

        </div>


        <div class="form-group">

          <label>
            주요 플랫폼
          </label>

          <select
            v-model="form.platform"
          >
            <option>
              Instagram
            </option>

            <option>
              TikTok
            </option>

            <option>
              YouTube
            </option>

            <option>
              Blog
            </option>
          </select>

        </div>


        <div class="form-group">

          <label>
            시작일
          </label>

          <input
            v-model="form.startDate"
            type="date"
          />

        </div>


        <div class="form-group">

          <label>
            종료일
          </label>

          <input
            v-model="form.endDate"
            type="date"
          />

        </div>


        <div class="form-group">

          <label>
            콘텐츠 업로드 마감
          </label>

          <input
            v-model="form.deadline"
            type="date"
          />

        </div>


        <div class="form-group full">

          <label>
            캠페인 설명
          </label>

          <textarea
            v-model="form.description"
            placeholder="캠페인 목적이나 가이드 내용을 입력하세요."
          />

        </div>

      </div>


      <div class="form-actions">

        <button
          type="button"
          class="secondary-button"

          @click="
            router.back()
          "
        >
          취소
        </button>

        <button
          class="primary-button"
        >
          캠페인 생성
        </button>

      </div>

    </form>

  </section>

</template>