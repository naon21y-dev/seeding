<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          PERFORMANCE
        </span>

        <h1>
          Analytics
        </h1>

        <p>
          시딩 캠페인의 전체 성과를 확인합니다.
        </p>

      </div>

    </div>


    <div class="analytic-summary">

      <div>
        <span>
          TOTAL CONTENTS
        </span>

        <strong>
          291
        </strong>
      </div>

      <div>
        <span>
          TOTAL VIEWS
        </span>

        <strong>
          8.42M
        </strong>
      </div>

      <div>
        <span>
          AVG VIEWS
        </span>

        <strong>
          28.9K
        </strong>
      </div>

      <div>
        <span>
          UPLOAD RATE
        </span>

        <strong>
          77.4%
        </strong>
      </div>

    </div>


    <div class="analytics-row">

      <section class="panel">

        <div class="panel-header">

          <div>
            <h2>
              Campaign Performance
            </h2>

            <p>
              캠페인별 조회수
            </p>
          </div>

        </div>


        <div class="fake-chart">

          <div style="height: 45%">
            <span>
              Glow Tint
            </span>
          </div>

          <div style="height: 72%">
            <span>
              Cushion
            </span>
          </div>

          <div style="height: 60%">
            <span>
              MLBB
            </span>
          </div>

          <div style="height: 82%">
            <span>
              Mist
            </span>
          </div>

          <div style="height: 52%">
            <span>
              Serum
            </span>
          </div>

        </div>

      </section>


      <section class="panel">

        <div class="panel-header">

          <div>
            <h2>
              Platform
            </h2>

            <p>
              플랫폼 콘텐츠 비중
            </p>
          </div>

        </div>


        <div class="platform-row">

          <div>
            <span>
              Instagram
            </span>

            <strong>
              58%
            </strong>
          </div>

          <div class="line">
            <span style="width: 58%" />
          </div>

        </div>


        <div class="platform-row">

          <div>
            <span>
              TikTok
            </span>

            <strong>
              31%
            </strong>
          </div>

          <div class="line">
            <span style="width: 31%" />
          </div>

        </div>


        <div class="platform-row">

          <div>
            <span>
              YouTube
            </span>

            <strong>
              11%
            </strong>
          </div>

          <div class="line">
            <span style="width: 11%" />
          </div>

        </div>

      </section>

    </div>

  </section>

</template>

<style scoped>
.analytic-summary {
  display: grid;

  grid-template-columns:
    repeat(4, 1fr);

  gap: 15px;

  margin-bottom: 18px;
}

.analytic-summary > div {
  display: flex;
  flex-direction: column;

  padding: 22px;

  background: white;

  border: 1px solid #ececef;

  border-radius: 15px;
}

.analytic-summary span {
  color: #999;

  font-size: 9px;

  letter-spacing: 1px;
}

.analytic-summary strong {
  margin-top: 12px;

  font-size: 28px;
}

.analytics-row {
  display: grid;

  grid-template-columns:
    2fr 1fr;

  gap: 18px;
}

.fake-chart {
  height: 270px;

  display: flex;
  align-items: flex-end;

  gap: 22px;

  padding-top: 30px;

  border-bottom:
    1px solid #ddd;
}

.fake-chart > div {
  flex: 1;

  position: relative;

  min-height: 30px;

  background: #242427;

  border-radius:
    8px 8px 0 0;
}

.fake-chart span {
  position: absolute;

  bottom: -30px;
  left: 0;

  width: 100%;

  text-align: center;

  color: #999;

  font-size: 9px;
}

.platform-row {
  margin-bottom: 25px;
}

.platform-row > div:first-child {
  display: flex;

  justify-content:
    space-between;

  font-size: 11px;

  margin-bottom: 8px;
}

.line {
  height: 6px;

  background: #eee;

  border-radius: 20px;

  overflow: hidden;
}

.line span {
  display: block;

  height: 100%;

  background: #242427;

  border-radius: 20px;
}
</style>