<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const campaigns = [
  {
    id: 1,
    name: 'FW Glow Tint Seeding',
    product: 'Glow Tint #01 · #02 · #03',
    people: '82 / 100',
    upload: 61,
    deadline: 'D-7',
  },
  {
    id: 2,
    name: 'Glass Skin Cushion',
    product: 'Glow Cushion Launch Campaign',
    people: '54 / 70',
    upload: 29,
    deadline: 'D-12',
  },
  {
    id: 3,
    name: 'Autumn MLBB Collection',
    product: 'Velvet Lip Series',
    people: '61 / 80',
    upload: 42,
    deadline: 'D-4',
  },
]

const goCampaign = id => {
  router.push(`/campaigns/${id}`)
}
</script>

<template>

  <section>

    <div class="page-header">

      <div>

        <span class="page-eyebrow">
          BEAUTY SEEDING
        </span>

        <h1>
          Marketing Dashboard
        </h1>

        <p>
          오늘의 인플루언서 시딩 현황을 확인하세요.
        </p>

      </div>

      <button
        class="primary-button"
        @click="router.push('/campaigns/new')"
      >
        + 새 캠페인
      </button>

    </div>


    <div class="summary-grid">

      <article class="summary-card">

        <span>
          진행중 캠페인
        </span>

        <strong>
          8
        </strong>

        <small>
          THIS MONTH +2
        </small>

      </article>


      <article class="summary-card">

        <span>
          전체 시딩
        </span>

        <strong>
          428
        </strong>

        <small>
          INFLUENCERS
        </small>

      </article>


      <article class="summary-card">

        <span>
          배송 완료
        </span>

        <strong>
          376
        </strong>

        <small>
          87.8%
        </small>

      </article>


      <article class="summary-card">

        <span>
          콘텐츠 업로드
        </span>

        <strong>
          291
        </strong>

        <small>
          77.4%
        </small>

      </article>

    </div>


    <div class="dashboard-row">

      <section class="panel campaigns">

        <div class="panel-header">

          <div>
            <h2>
              Active Campaigns
            </h2>

            <p>
              현재 진행중인 시딩 캠페인
            </p>
          </div>

          <button
            class="secondary-button"
            @click="router.push('/campaigns')"
          >
            전체보기
          </button>

        </div>


        <article
          v-for="campaign in campaigns"
          :key="campaign.id"
          class="campaign-row"

          @click="goCampaign(campaign.id)"
        >

          <div class="product-box">
            BEAUTY
          </div>

          <div class="campaign-row-info">

            <div>
              <span class="status-badge status-active">
                진행중
              </span>
            </div>

            <strong>
              {{ campaign.name }}
            </strong>

            <span>
              {{ campaign.product }}
            </span>

          </div>


          <div class="campaign-number">

            <small>
              SEEDING
            </small>

            <strong>
              {{ campaign.people }}
            </strong>

          </div>

          <div class="campaign-number">

            <small>
              UPLOAD
            </small>

            <strong>
              {{ campaign.upload }}
            </strong>

          </div>

          <span class="deadline">
            {{ campaign.deadline }}
          </span>

        </article>

      </section>


      <section class="panel tasks">

        <div class="panel-header">

          <div>

            <h2>
              Today's Tasks
            </h2>

            <p>
              오늘 확인이 필요한 업무
            </p>

          </div>

        </div>

        <div class="task-list">

          <div class="task">

            <div>
              <strong>
                업로드 기한 초과
              </strong>

              <span>
                콘텐츠 미업로드
              </span>
            </div>

            <b class="danger-number">
              17
            </b>

          </div>


          <div class="task">

            <div>
              <strong>
                오늘 발송 예정
              </strong>

              <span>
                배송 준비 필요
              </span>
            </div>

            <b>
              42
            </b>

          </div>


          <div class="task">

            <div>
              <strong>
                컨택 답변 대기
              </strong>

              <span>
                회신 확인 필요
              </span>
            </div>

            <b>
              31
            </b>

          </div>


          <div class="task">

            <div>
              <strong>
                신규 콘텐츠
              </strong>

              <span>
                오늘 등록
              </span>
            </div>

            <b>
              26
            </b>

          </div>

        </div>

      </section>

    </div>


    <div class="bottom-row">

      <section class="panel">

        <div class="panel-header">

          <div>
            <h2>
              Seeding Funnel
            </h2>

            <p>
              전체 시딩 진행 단계
            </p>
          </div>

        </div>


        <div class="funnel">

          <div>
            <span>후보</span>
            <strong>428</strong>
          </div>

          <div>
            <span>컨택</span>
            <strong>391</strong>
          </div>

          <div>
            <span>수락</span>
            <strong>376</strong>
          </div>

          <div>
            <span>배송</span>
            <strong>338</strong>
          </div>

          <div>
            <span>업로드</span>
            <strong>291</strong>
          </div>

        </div>

      </section>


      <section class="panel">

        <div class="panel-header">

          <div>
            <h2>
              Recent Contents
            </h2>

            <p>
              최근 업로드
            </p>
          </div>

        </div>


        <div class="recent-content">

          <div>

            <div class="content-thumb">
              IMG
            </div>

            <div>
              <strong>
                @beauty_mina
              </strong>

              <span>
                Instagram Reel
              </span>
            </div>

            <b>
              82.4K
            </b>

          </div>


          <div>

            <div class="content-thumb">
              IMG
            </div>

            <div>
              <strong>
                @suu_makeup
              </strong>

              <span>
                TikTok
              </span>
            </div>

            <b>
              151K
            </b>

          </div>

        </div>

      </section>

    </div>

  </section>

</template>

<style scoped>
.summary-grid {
  display: grid;

  grid-template-columns:
    repeat(4, 1fr);

  gap: 15px;

  margin-bottom: 18px;
}

.summary-card {
  display: flex;
  flex-direction: column;

  padding: 23px;

  background: white;

  border: 1px solid #ececef;
  border-radius: 16px;
}

.summary-card span {
  color: #787880;

  font-size: 11px;
  font-weight: 600;
}

.summary-card strong {
  margin-top: 14px;

  font-size: 30px;
}

.summary-card small {
  margin-top: 9px;

  color: #aaaaaf;

  font-size: 9px;
  letter-spacing: 1px;
}

.dashboard-row {
  display: grid;

  grid-template-columns:
    2fr 1fr;

  gap: 18px;

  margin-bottom: 18px;
}

.campaign-row {
  display: grid;

  grid-template-columns:
    52px 1fr 80px 80px 55px;

  gap: 14px;

  align-items: center;

  padding: 14px 0;

  border-bottom:
    1px solid #eeeef1;

  cursor: pointer;
}

.campaign-row:last-child {
  border-bottom: none;
}

.product-box {
  width: 48px;
  height: 48px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 12px;

  background: #f2ecef;

  font-size: 8px;
  font-weight: 800;

  color: #7b6870;
}

.campaign-row-info {
  display: flex;
  flex-direction: column;

  gap: 5px;
}

.campaign-row-info strong {
  font-size: 12px;
}

.campaign-row-info > span {
  color: #999;

  font-size: 10px;
}

.campaign-number {
  display: flex;
  flex-direction: column;

  gap: 4px;
}

.campaign-number small {
  color: #aaa;

  font-size: 8px;
}

.campaign-number strong {
  font-size: 11px;
}

.deadline {
  font-size: 11px;

  font-weight: 800;
}

.task-list {
  display: flex;

  flex-direction: column;
}

.task {
  display: flex;
  justify-content:
    space-between;
  align-items: center;

  padding: 16px 0;

  border-bottom:
    1px solid #eeeef1;
}

.task:last-child {
  border-bottom: none;
}

.task div {
  display: flex;
  flex-direction: column;

  gap: 5px;
}

.task strong {
  font-size: 11px;
}

.task span {
  color: #999;

  font-size: 9px;
}

.task b {
  font-size: 18px;
}

.danger-number {
  color: #d84646;
}

.bottom-row {
  display: grid;

  grid-template-columns:
    1fr 1fr;

  gap: 18px;
}

.funnel {
  display: grid;

  grid-template-columns:
    repeat(5, 1fr);

  gap: 10px;
}

.funnel div {
  display: flex;
  flex-direction: column;

  gap: 10px;

  padding: 18px;

  border-radius: 12px;

  background: #f8f8fa;
}

.funnel span {
  color: #8a8a91;

  font-size: 9px;
}

.funnel strong {
  font-size: 19px;
}

.recent-content > div {
  display: grid;

  grid-template-columns:
    46px 1fr auto;

  gap: 12px;

  align-items: center;

  padding: 11px 0;
}

.content-thumb {
  width: 45px;
  height: 45px;

  display: flex;
  align-items: center;
  justify-content: center;

  background: #eee;

  border-radius: 10px;

  font-size: 8px;
}

.recent-content > div > div:nth-child(2) {
  display: flex;
  flex-direction: column;

  gap: 4px;
}

.recent-content strong {
  font-size: 11px;
}

.recent-content span {
  color: #999;

  font-size: 9px;
}

.recent-content b {
  font-size: 11px;
}
</style>