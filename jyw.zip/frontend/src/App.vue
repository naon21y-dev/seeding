<script setup>
import AppSidebar from '@/components/layout/AppSidebar.vue'
</script>

<template>
  <div class="app-layout">

    <AppSidebar />

    <div class="app-main">

      <header class="top-header">

        <div>
          <span class="top-label">
            BEAUTY MARKETING
          </span>

          <strong>
            Influencer Seeding Manager
          </strong>
        </div>

        <div class="header-right">

          <button class="icon-button">
            알림
          </button>

          <div class="user-area">

            <div class="avatar">
              M
            </div>

            <div>
              <strong>
                Marketing Team
              </strong>

              <span>
                Manager
              </span>
            </div>

          </div>

        </div>

      </header>

      <main class="page-container">
        <RouterView />
      </main>

    </div>

  </div>
</template>