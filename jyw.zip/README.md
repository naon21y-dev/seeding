# Beauty Seeding Manager

- backend: Spring Boot
- frontend: Vue 3 + Vite
